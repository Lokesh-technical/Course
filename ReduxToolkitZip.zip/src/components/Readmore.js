import React from 'react'

const Readmore = () => {
  return (
    <div className='flex justify-center flex-col '>
        <h1 className='mt-5 font-bold text-3xl text-white'>Welcome to indias no  1 education</h1>
        <p className='text-white'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Neque asperiores eveniet recusandae velit ex, dicta laboriosam ratione explicabo eaque expedita? Recusandae voluptatibus a similique nesciunt enim corporis nobis. Deserunt, magni nam ullam veritatis quae, maiores molestias perferendis quas in dignissimos similique quam a! Aut, aspernatur incidunt. Temporibus voluptatem similique ad?</p>
    </div>
  )
}

export default Readmore